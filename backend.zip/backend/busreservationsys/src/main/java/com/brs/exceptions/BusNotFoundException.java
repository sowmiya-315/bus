package com.brs.exceptions;

@SuppressWarnings("serial")
public class BusNotFoundException extends Exception {
	public BusNotFoundException(String message) {
		super(message);

	}
}