package com.brs.exceptions;

@SuppressWarnings("serial")
public class FeedBackNotFoundException extends Exception {
	public FeedBackNotFoundException(String message) {
		super(message);
	}
}
