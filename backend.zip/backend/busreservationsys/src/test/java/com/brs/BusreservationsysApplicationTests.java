package com.brs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusreservationsysApplicationTests {

	@Test
	void contextLoads() {
	}

}
